<?php 
include('inc/header.php');
if(isset($_SESSION['ROLE']) + $_SESSION['ROLE']!='2') + $_SESSION['ROLE']!='1'{
	
	header('location:login.php')

}





?>
<div class="container-fluid">
   <!-- DataTables Example -->
   <div class="card mb-3">
	  <div class="card-header">
		 <i class="fa fa-fw fa-user"></i>
		 Student Table
	  </div>
	  <div class="card-body">
		 <div class="table-responsive">
			<table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
			<a class="btn btn-success" href="studentadd.php" role="button">Add New Student</a>
			   <thead>
				  <tr>
					 <th>Name</th>
					 <th>City</th>
					 <th>Email</th>
					 <th>Action</th>
				  </tr>
			   </thead>
			  
			   <tbody>
				  <tr>
					 <td>Vishal Gupta</td>
					 <td>Delhi</td>
					 <td>vishal@gmail.com</td>
					 <td><button type="button"  class="btn btn-primary">Edit</button>
					 <button type="button" class="btn btn-danger">Danger</button></td>
				 
				  </tr>
				  <tr>
					 <td>Bhaavit Gupta</td>
					 <td>Noida</td>
					 <td>bhaavit@gmail.com</td>
					 <td><button type="button" class="btn btn-primary">Edit</button>
					 <button type="button" class="btn btn-danger">Danger</button></td>
				 
				  </tr>
			   </tbody>
			</table>
		 </div>
	  </div>
   </div>
</div>
<?php include('inc/footer.php')?>