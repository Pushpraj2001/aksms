
# Database
City state country dropdown : http://lab.iamrohit.in/php_ajax_country_state_city_dropdown/ 
Download full source code: http://www.iamrohit.in/tag/php-ajax-country-state-city-dropdown

# Note: 
*This Free database dose not guarantee for the complete list of world countries, states and cities.

*You can manually change the spelling mistakes, or add edit any records, which are not correct.
